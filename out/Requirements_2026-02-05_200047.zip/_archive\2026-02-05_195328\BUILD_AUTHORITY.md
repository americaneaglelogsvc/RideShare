# Build Authority (STRICT)

The ONLY requirements source-of-truth is:
- BlackRavenia_RideShare_Canonical_Requirements_v6_1.md

All other documents are governance/process artifacts only.
They MUST NOT be used to create or change requirements.

If a capability is missing, update ONLY the canonical requirements document.
